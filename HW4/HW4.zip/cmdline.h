//
// Created by Melanie Prettyman on 1/11/24.
//

#ifndef MSDSCRIPT_CMDLINE_H
#define MSDSCRIPT_CMDLINE_H


void use_arguments(int argc, char **argv);

#endif //MSDSCRIPT_CMDLINE_H
