#include <iostream>
#include "cmdline.h"

int main(int argc, char **argv) {

    use_arguments(argc, argv);


//    while (1) {
//        Expr *e = parse_expr(std::cin);
//        e->pretty_print(std::cout);
//        std::cout << "\n";
//        skip_whitespace(std::cin);
//        if (std::cin.eof())
//            break;
//    }

    return 0;

}
