#include "mainwidget.h"


mainWidget::mainWidget(QWidget *parent)
    : QWidget{parent},
    nameEdit(new QLineEdit),
    ageSpinBox(new QSpinBox),
    maleButton(new QRadioButton("Male")),
    femaleButton(new QRadioButton("Female")),
    otherButton(new QRadioButton("Other")),
    refreshButton(new QPushButton("Update")),
    finishButton(new QPushButton("Clear")),
    summaryTextEdit(new QTextEdit),
    mainLayout(new QVBoxLayout)
{

    setGridLayout();
    setLayout(mainLayout);

    connect(refreshButton, &QPushButton::clicked, this, &mainWidget::fillSummary);
    connect(finishButton, &QPushButton::clicked, this, &mainWidget::clearWidgets);

}

//Function to create gridLayout
void mainWidget::setGridLayout() {

    //Create grid-layout
    QGridLayout *gridLayout = new QGridLayout;

    //Name box
    QGroupBox *nameBox = new QGroupBox("Name:");
    QHBoxLayout *nameLayout = new QHBoxLayout;
    nameEdit->setPlaceholderText("Enter your name");
    nameLayout->addWidget(nameEdit);
    ageSpinBox->setRange(0, 100);
    nameLayout->addWidget(new QLabel("Age:"));
    nameLayout->addWidget(ageSpinBox);
    nameBox->setLayout(nameLayout);

    //Gender box
    QGroupBox *genderBox = new QGroupBox("Select Gender:");
    QHBoxLayout *radioLayout = new QHBoxLayout;
    radioLayout->addWidget(maleButton);
    radioLayout->addWidget(femaleButton);
    radioLayout->addWidget(otherButton);
    genderBox->setLayout(radioLayout);


    //Summary box
    QGroupBox *summaryBox = new QGroupBox();
    QHBoxLayout *summaryLayout = new QHBoxLayout;
    summaryTextEdit->setPlaceholderText("Summary will appear here.");
    summaryLayout->addWidget(summaryTextEdit);
    summaryBox->setLayout(summaryLayout);


    //Add name, gender, and summary boxes
    gridLayout->addWidget(nameBox, 0, 0, 1, 2);
    gridLayout->addWidget(genderBox, 1, 0, 1, 2);
    gridLayout->addWidget(summaryBox, 2, 0, 1, 2);
    gridLayout->addWidget(refreshButton, 3, 0);
    gridLayout->addWidget(finishButton, 3, 1);

    //Add gridLayout to mainlayout
    mainLayout->addItem(gridLayout);

}

//Function is called when the 'Update' button is clicked. Collects the inputed info and prints it out in the summary field.
void mainWidget::fillSummary() {
    QString summary = QString("First Name: %1\nAge: %2\nGender: %3")
                          .arg(nameEdit->text())
                          .arg(ageSpinBox->value())
                          .arg(maleButton->isChecked() ? "Male" : femaleButton->isChecked() ? "Female" : "Other");
    summaryTextEdit->setText(summary);
}

//Function is called when the 'Clear' button is clicked. Clears all input fields.
void mainWidget::clearWidgets() {
    nameEdit->clear();
    ageSpinBox->setValue(0);
    maleButton->setChecked(false);
    femaleButton->setChecked(false);
    otherButton->setChecked(false);
    summaryTextEdit->clear();
}
