#ifndef MAINWIDGET_H
#define MAINWIDGET_H

#include <QWidget>
#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QDialogButtonBox>
#include <QRadioButton>
#include <QPushButton>
#include <QTextEdit>
#include <QVBoxLayout>
#include <QGroupBox>
#include <QSpinBox>



class mainWidget : public QWidget
{
    Q_OBJECT
public:
    explicit mainWidget(QWidget *parent = nullptr);


    void setGridLayout(QGridLayout *layout);

    QLineEdit *nameEdit;
    QSpinBox *ageSpinBox;
    QRadioButton *maleButton, *femaleButton, *otherButton;
    QPushButton *refreshButton, *finishButton;
    QTextEdit *summaryTextEdit;
    QVBoxLayout *mainLayout;

    void setGridLayout();
    void clearWidgets();

    void fillSummary();

signals:
};

#endif // MAINWIDGET_H
